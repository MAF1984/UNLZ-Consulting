package edu.unlz.taller.programacion.tp.individual;

/**
 * @author maf
 *
 */

public interface Imprimible {

	public static void imprimirDatos() {
	}
}
